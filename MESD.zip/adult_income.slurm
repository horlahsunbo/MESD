#!/bin/bash
#SBATCH --account=priority-johnsheppard
#SBATCH --partition=priority
#SBATCH --nodes=1
#SBATCH --cpus-per-task=32
#SBATCH --mem=64G
#SBATCH --time=6-00:00:00
#SBATCH --job-name=mesd_german_job
#SBATCH --output=mesd_german_job-%j.out
#SBATCH --error=mesd_german_job-%j.err
#SBATCH --mail-user=gideon.popoola@student.montana.edu
#SBATCH --mail-type=ALL

# Load environment
source ~/.bashrc
conda activate Gideonenv

# Go to your home directory
cd /home/n88r684/MESD


# Run your script
date
python  MESD_new.py
date                                # print the date again