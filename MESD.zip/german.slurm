#!/bin/bash
#SBATCH --account=priority-johnsheppard
#SBATCH --partition=priority
#SBATCH --nodes=1
#SBATCH --cpus-per-task=64
#SBATCH --mem=64G
#SBATCH --time=9-00:00:00
#SBATCH --job-name=mesd_additional
#SBATCH --output=mesd_additional-%j.out
#SBATCH --error=mesd_additional-%j.err
#SBATCH --mail-user=gideon.popoola@student.montana.edu
#SBATCH --mail-type=ALL

# Load environment
source ~/.bashrc
conda activate Gideonenv

# Go to your home directory
cd /home/n88r684/MESD


# Run your script
date
python 	MESD_additional_datasets.py
date        