"""
MESD — COMPAS Experiments 3-7
==============================
Runs EXP3 (CVaR effect), EXP4 (ablation), EXP5 (sensitivity),
EXP6 (perturbation baseline), EXP7 (Chebyshev weights) on the 
ProPublica COMPAS dataset.

Uses a single 70/30 stratified split (same as main script's EXP2-7).
Imports experiment functions from MESD_unified.py.

Usage:
  python MESD_compas_exp3to7.py

Output:
  results_compas/compas/exp3/ through exp7/
"""

import os, sys, time, warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import LogisticRegression

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
os.environ["XLA_FLAGS"] = "--xla_gpu_unsafe_fallback_to_driver_on_ptxas_not_found"
import tensorflow as tf
tf.get_logger().setLevel("ERROR")

# Import from main scripts
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from MESD_unified import (MESDCalculator, set_random_seeds,
                          run_exp3, run_exp4, run_exp5, run_exp6, run_exp7)
from MESD_compas import load_compas

RESULTS_DIR = "results_compas"


def main():
    print("=" * 70)
    print("MESD — COMPAS Experiments 3-7")
    print("=" * 70)
    
    global_t0 = time.time()
    
    # Load COMPAS
    X, y, sens, cfg = load_compas()
    
    # Single 70/30 split for EXP3-7 (same protocol as main script)
    set_random_seeds(42)
    Xtr, Xte, ytr, yte, str_, ste = train_test_split(
        X, y, sens, test_size=0.3, random_state=42, stratify=y)
    sc = StandardScaler()
    Xtr = sc.fit_transform(Xtr)
    Xte = sc.transform(Xte)
    mc = MESDCalculator(cvar_alpha=0.1, random_seed=42)
    
    out = os.path.join(RESULTS_DIR, "compas")
    
    # EXP3: CVaR effect
    print(f"\n{'='*70}")
    print("Running EXP3 (CVaR effect) on COMPAS...")
    run_exp3(Xtr, ytr, Xte, yte, str_, ste, mc, cfg, os.path.join(out, "exp3"), 42)
    print(f"  [ELAPSED] {(time.time()-global_t0)/3600:.1f} hr")
    
    # EXP4: Ablation
    print(f"\n{'='*70}")
    print("Running EXP4 (ablation) on COMPAS...")
    run_exp4(Xtr, ytr, Xte, yte, ste, os.path.join(out, "exp4"), 42)
    print(f"  [ELAPSED] {(time.time()-global_t0)/3600:.1f} hr")
    
    # EXP5: Sensitivity (K, sigma, explainer weights)
    print(f"\n{'='*70}")
    print("Running EXP5 (sensitivity) on COMPAS...")
    run_exp5(Xtr, ytr, Xte, yte, ste, os.path.join(out, "exp5"), 42)
    print(f"  [ELAPSED] {(time.time()-global_t0)/3600:.1f} hr")
    
    # EXP6: Perturbation baseline
    print(f"\n{'='*70}")
    print("Running EXP6 (perturbation baseline) on COMPAS...")
    run_exp6(Xtr, ytr, Xte, yte, ste, os.path.join(out, "exp6"), 42)
    print(f"  [ELAPSED] {(time.time()-global_t0)/3600:.1f} hr")
    
    # EXP7: Chebyshev weight sensitivity
    print(f"\n{'='*70}")
    print("Running EXP7 (Chebyshev weights) on COMPAS...")
    run_exp7(Xtr, ytr, Xte, yte, ste, mc, cfg, os.path.join(out, "exp7"), 42)
    print(f"  [ELAPSED] {(time.time()-global_t0)/3600:.1f} hr")
    
    total = (time.time() - global_t0) / 3600
    print(f"\n{'='*70}")
    print(f"ALL COMPAS EXPERIMENTS (3-7) COMPLETE — {total:.1f} hr")
    print(f"Results in: {out}/")
    print("=" * 70)


if __name__ == "__main__":
    main()
