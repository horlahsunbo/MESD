#!/bin/bash
#SBATCH --account=priority-johnsheppard
#SBATCH --partition=priority
#SBATCH --nodes=1
#SBATCH --cpus-per-task=12
#SBATCH --mem=32G
#SBATCH --time=6-00:00:00
#SBATCH --job-name=mesd_compas_job
#SBATCH --output=mesd_compas_job-%j.out
#SBATCH --error=mesd_compas_job-%j.err
#SBATCH --mail-user=gideon.popoola@student.montana.edu
#SBATCH --mail-type=ALL

# Load environment
source ~/miniconda3/etc/profile.d/conda.sh
conda activate Gideonenv

# Go to your home directory
cd /home/n88r684/MESD


# Run your script
date
python MESD_compas_3.py
date                                # print the date again